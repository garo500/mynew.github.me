<?

$to = "chksemma@gmail.com,laura.cuevas@yandex.com";

?>